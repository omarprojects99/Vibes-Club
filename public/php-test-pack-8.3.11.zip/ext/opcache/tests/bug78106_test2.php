<?php

require_once 'bug78106_include.inc';

echo "done\n";
